//
//  customSegmentControllForLocalization.swift
//  Baxter
//
//  Created by Ahemadabbas Vagh on 04/03/19.
//  Copyright © 2019 Codal Inc. All rights reserved.
//
import UIKit
/// It's used to add localization support for segment controll that reflact directly via IB.
class CustomLocalizeSegmentControl: UISegmentedControl, LocalizationDelegate {
    // MARK:- Variables
    /// Used to prepare the file name based that we can find localization string in that file.
    private var _fileName: String?
    /// Used to prepare the localization key for index 0.
    private var _xibLocKey1: String?
    /// Used to prepare the localization key for index 1.
    private var _xibLocKey2: String?
    /// Used to keep track of string has attribute or not.
    private var hasAttribute: Bool?
    /// Used prepare file name for the localization.
    @IBInspectable var fileName: String? {
        didSet {
            _fileName = fileName ?? ""
        }
    }
    /// Used to prepare the localization key.
    @IBInspectable var xibLocKey: String? {
        didSet {
            let keys = (xibLocKey ?? "").split(separator: ",")
            _xibLocKey1 = String(keys.first ?? "")
            _xibLocKey2 = String(keys.last ?? "")
        }
    }
    /// Used prepare strings contain attribute.
    @IBInspectable var isAttributed: Bool = false {
        didSet {
            hasAttribute = isAttributed
        }
    }
    // MARK:- LifeCycle Methods
    /// Prepares the receiver for service after it has been loaded from an Interface Builder archive, or nib file.
    override func awakeFromNib() {
        super.awakeFromNib()
        translateTheText()
    }
    // MARK:- Functions
    /// It's used to translate the text based on the file name and the localization strings.
    private func translateTheText() {
        if let fileName = _fileName {
            let font = UIFont(name: "DINNextLTPro-Medium", size: 12)
            setTitleTextAttributes([NSAttributedString.Key.font: font!], for: .normal)
            setTitle(_xibLocKey1?.localized(tableName: FileName(rawValue: fileName)!), forSegmentAt: 0)
            setTitle(_xibLocKey2?.localized(tableName: FileName(rawValue: fileName)!), forSegmentAt: 1)
        }
    }
}
