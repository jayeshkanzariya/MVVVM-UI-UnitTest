//
//  CustomPrintPageRenderer.swift
//  Print2PDF
//
//  Created by Ahemadabbas Vagh on 28/02/19.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import UIKit

/// This Class is resposible for draw header and footer for the PDF.

class CustomPrintPageRenderer: UIPrintPageRenderer {
    
    // MARK: Variables & Constant
    let usLetterWidth: CGFloat = 612.0
    let usLetterHeight: CGFloat = 792.0
    let heightForHeader: CGFloat = 23.0
    let heightForFooter: CGFloat = 10.0
    let firstPageBackGroundColor = "#FFFFFF"
    let otherPageColor = "#EBEDF1"
    
    // MARK: Life Cycle Methods

    override init() {
        super.init()
        
        // Specify the frame of the A4 page.
        let pageFrame = CGRect(x: 0.0, y: 0.0, width: usLetterWidth, height: usLetterHeight)
        
        // Set the page frame.
        self.setValue(NSValue(cgRect: pageFrame), forKey: "paperRect")
        
        // Set the horizontal and vertical insets (that's optional).
        self.setValue(NSValue(cgRect: CGRect(x: 0, y: 0, width: usLetterWidth, height: usLetterHeight)), forKey: "printableRect")
    
        self.headerHeight = heightForHeader // add the header height for pdf.
        self.footerHeight = heightForFooter // add the footer height for pdf.
    }
    
    override func drawHeaderForPage(at pageIndex: Int, in headerRect: CGRect) {
        
        let image = UIImage(named: "baxter_pdf_header_logo")! // get the logo of baxter.
        
        let font2 = UIFont(name: "DINNextLTPro-Medium", size: 14) // font for hospital name.

        let text2 =  ScreenshotManager.shared.hospitalName // get the hospital name.

        let attributes2 = [NSAttributedString.Key.font: font2!, NSAttributedString.Key.foregroundColor: UIColor(red: 78.0/255.0, green: 89.0/255.0, blue: 102.0/255.0, alpha: 1)] // set attribute for hospital name.

        let text2Size = getTextSize(text: text2 ?? "", font: font2!) // get the text size for hospital font.
 
        let centerX = headerRect.origin.x + 15 // set the x position for the baxter logo.
        
        image.draw(at: CGPoint(x: centerX, y: (headerRect.height / 2)-(image.size.height / 2))) // draw baxter logo.
        text2?.draw(at: CGPoint(x: (headerRect.width / 2)-(text2Size.width / 2), y: (headerRect.height / 2)-(text2Size.height / 2)),withAttributes: attributes2)
        
        let banchmarkTitle = "\(strPDFBanchmarkCaps) \(sharedAppDelegate.isCoeOn ? sharedAppDelegate.selectedCOEAbbrivation : exportNaOblic)"
        let attributedString = NSMutableAttributedString(string: banchmarkTitle)
        let benchmarkTitleFont = UIFont(name: "Geogrotesque-SemiBold", size: 12)
    attributedString.addAttributes([NSAttributedString.Key.font:benchmarkTitleFont!,NSAttributedString.Key.foregroundColor:UIColor(red: 6.0/255.0, green: 88.0/255.0, blue: 149.0/255.0, alpha: 1)], range: NSRange(banchmarkTitle.range(of: strPDFBanchmarkCaps)!, in: banchmarkTitle))
        
        let benchmarkValueFont = UIFont(name: "Geogrotesque-SemiBold", size: 11)
    attributedString.addAttributes([NSAttributedString.Key.font:benchmarkValueFont!,NSAttributedString.Key.foregroundColor:UIColor(red: 69.0/255.0, green: 79.0/255.0, blue: 91.0/255.0, alpha: 1)], range: NSRange(banchmarkTitle.range(of: "\(sharedAppDelegate.isCoeOn ? sharedAppDelegate.selectedCOEAbbrivation :exportNaOblic)")!, in: banchmarkTitle))
        
        let size = getTextSize(text: banchmarkTitle, font: benchmarkTitleFont!)
        attributedString.draw(at: CGPoint(x: headerRect.width - (size.width + 15), y: (headerRect.height / 2)-(text2Size.height / 2)))
    }
    
    override func drawFooterForPage(at pageIndex: Int, in footerRect: CGRect) {
        
        // below context is used to add the background color to the pdf footer.
        let context = UIGraphicsGetCurrentContext()
        context?.move(to: CGPoint(x: footerRect.minX, y: footerRect.origin.y))
        context?.setFillColor(UIColor(hex: otherPageColor).cgColor)
        context?.setStrokeColor(UIColor(hex: otherPageColor).cgColor)
        context?.addRect(footerRect)
        context?.drawPath(using: .fillStroke)
        
        var fottertextForPages = "\(strPDFPage) \(pageIndex + 1)" // create text for ex: page 1 of 10
        let font = UIFont(name: "DINNextLTPro-Medium", size: 10) // prepare font for footer text.
        let textPageSize = getTextSize(text: fottertextForPages as String, font: font!) // get the text size for the footer number of page text.
        let centerXForPage = footerRect.size.width - (textPageSize.width + 10) // prepare x position for number of page text.
        let pageNoattributes = [NSAttributedString.Key.font: font!, NSAttributedString.Key.foregroundColor: UIColor(red: 0.13, green: 0.17, blue: 0.21, alpha: 1)] // prepare attributes for all the footer text.
        
        if pageIndex == 0 {
            
            fottertextForPages = "\(strPDFPage) \(pageIndex + 1)"
            
            let disclaimerText = strDisclaimer + "\n\n" + "V \(String(describing: Bundle.main.releaseVersionNumber))"
            let font = UIFont(name: "DINNextLTPro-Regular", size: 10) // prepare font for footer text.
            
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            
            
            let attributes = [NSAttributedString.Key.font: font!, NSAttributedString.Key.foregroundColor: UIColor(red: 0.13, green: 0.17, blue: 0.21, alpha: 1),NSAttributedString.Key.paragraphStyle: paragraphStyle] // prepare attributes for all the footer text.
            
           //draw footer number of pages text.
            
            // prepare the center position of footer.
            
            //draw footer number of pages text.
                        
            let height = strDisclaimer.height(withConstrainedWidth: 592, font: UIFont(name: "DINNextLTPro-Regular", size: 10)!) + 20
            
            let pageNumberY = (footerRect.origin.y + height + 10)
            
            fottertextForPages.draw(at: CGPoint(x: centerXForPage, y: pageNumberY), withAttributes: pageNoattributes)
            
            disclaimerText.draw(in: CGRect(x: footerRect.origin.x + 10,y: footerRect.origin.y, width: footerRect.size.width - 10, height: height), withAttributes :attributes)
        }
        
        else {
            let centerY = (footerRect.origin.y + self.footerHeight/2) - 10
            // prepare the center position of footer.
            //draw footer number of pages text.
            fottertextForPages.draw(at: CGPoint(x: centerXForPage, y: centerY), withAttributes: pageNoattributes)
        }
    }
    
    override func drawContentForPage(at pageIndex: Int, in contentRect: CGRect) {
        // below context is used to add the background color to the pdf context of the page..
        let context = UIGraphicsGetCurrentContext()
        context?.move(to: CGPoint(x: contentRect.minX, y: contentRect.origin.y))
        context?.setFillColor(UIColor(hex: pageIndex == 0 ? otherPageColor : otherPageColor).cgColor)
        context?.setStrokeColor(UIColor(hex: pageIndex == 0 ? otherPageColor : otherPageColor).cgColor)
        context?.addRect(contentRect)
        context?.drawPath(using: .fillStroke)
    }
    
    // MARK: Functions
    /// Function is used to get the size of the text.
    ///
    ///  - Parameters:
    ///         - text: The String text of the element.
    ///         - font: The font of the element.
    ///         - textAttributes: The attribute of the string font default value is nil.
    ///
    ///  - Returns: calculated size of the text.
 
    func getTextSize(text: String, font: UIFont!, textAttributes: [NSAttributedString.Key: Any]! = nil) -> CGSize {
        let testLabel = UILabel()
        if let attributes = textAttributes {
            testLabel.attributedText = NSAttributedString(string: text, attributes: attributes)
        } else {
            testLabel.text = text
            testLabel.font = font!
        }
        testLabel.sizeToFit()
        return testLabel.frame.size
    }
}

extension String {
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return ceil(boundingBox.height)
    }
}
