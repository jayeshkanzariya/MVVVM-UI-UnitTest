//
//  CustomTextFieldForLocalization.swift
//  Baxter
//
//  Created by Ahemadabbas Vagh on 04/03/19.
//  Copyright © 2019 Codal Inc. All rights reserved.
//
import UIKit
/// It's used to add localization support for text fields that reflact directly via IB.
class CustomLocalizedTextField: UITextField, LocalizationDelegate {
    // MARK:- Variables
    /// Used to prepare the file name based that we can find localization string in that file.
    private var _fileName: String?
    /// Used to prepare the localization key.
    private var _xibLocKey: String?
    /// Used prepare file name for the localization.
    @IBInspectable var fileName: String? {
        didSet {
            _fileName = fileName ?? ""
        }
    }
    /// Used to prepare the localization key.
    @IBInspectable var xibLocKey: String? {
        didSet {
            _xibLocKey = xibLocKey ?? ""
        }
    }
    // MARK:- LifeCycle Methods
    /// Prepares the receiver for service after it has been loaded from an Interface Builder archive, or nib file.
    override func awakeFromNib() {
        super.awakeFromNib()
        traslateTheText()
    }
    // MARK:- Functions
    /// It's used to translate the text based on the given file name and localization string.
    private func traslateTheText() {
        if let fileName = _fileName {
            placeholder = _xibLocKey?.localized(tableName: FileName(rawValue: fileName)!)
        }
    }
}
