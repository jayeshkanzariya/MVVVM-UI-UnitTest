//
//  CustomButtonForLocalization.swift
//  Baxter
//
//  Created by Ahemadabbas Vagh on 04/03/19.
//  Copyright © 2019 Codal Inc. All rights reserved.
//
import UIKit
/// It's used to add localization support for button that reflact directly via IB.
class CustomLocalizedButton: UIButton, LocalizationDelegate {
    //MARK:- Variables
    /// Used to prepare the file name based that we can find localization string in that file.
    private var _fileName: String?
    /// Used to prepare the localization key.
    private var _xibLocKey: String?
    /// Used to keep track of string has attribute or not.
    private var hasAttribute: Bool?
    /// Used to keep track of string has want to add manual space.
    private var hasSpace: Bool?
    /// Used to prepare strings need manual space or not.
    @IBInspectable var isStringContainSpace: Bool = false {
        didSet {
            hasSpace = isStringContainSpace
        }
    }
    /// Used prepare strings contain attribute.
    @IBInspectable var isAttributed: Bool = false {
        didSet {
            hasAttribute = isAttributed
        }
    }
    /// Used prepare file name for the localization.
    @IBInspectable var fileName: String? {
        didSet {
            _fileName = fileName ?? ""
        }
    }
    /// Used to prepare the localization key.
    @IBInspectable var xibLocKey: String? {
        didSet {
            _xibLocKey = xibLocKey ?? ""
        }
    }
    //MARK:- LifeCycle Methods
    /// Prepares the receiver for service after it has been loaded from an Interface Builder archive, or nib file.
    override func awakeFromNib() {
        super.awakeFromNib()
        updateTranslatedText()
    }
    //MARK:- Functions
    /// It's used to translate the string based on file name and localization key and it will add manual space if It's required.
    private func updateTranslatedText() {
        if let fileName = _fileName {
            if hasAttribute ?? false {
                if let attributedTitle = self.attributedTitle(for: .normal) {
                    let mutableAttributedTitle = NSMutableAttributedString(attributedString: attributedTitle)
                    let table = FileName(rawValue: fileName)!
                    mutableAttributedTitle.replaceCharacters(in: NSRange(location: 0, length: mutableAttributedTitle.length), with: NSAttributedString(string: (_xibLocKey?.localized(tableName: table))!))
                    self.setAttributedTitle(mutableAttributedTitle, for: .normal)
                    self.setAttributedTitle(mutableAttributedTitle, for: .selected)
                }
            } else {
                setTitle(_xibLocKey?.localized(tableName: FileName(rawValue: fileName)!), for: .normal)
                setTitle(_xibLocKey?.localized(tableName: FileName(rawValue: fileName)!), for: .selected)
            }
        }
        // if we want to add manual space then has space must be true so we can update the title for space.
        if hasSpace ?? false {
            updateTitle()
        }
    }
    /// It's used to add the eight space after the text.
    private func updateTitle() {
        if let text = self.titleLabel?.text {
            self.setTitle(text.addSpace(total: 8), for: .normal)
        }
    }
}
