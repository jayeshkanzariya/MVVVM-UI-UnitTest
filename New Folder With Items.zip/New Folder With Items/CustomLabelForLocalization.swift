//
//  CustomLabelForLocalization.swift
//  Baxter
//
//  Created by Ahemadabbas Vagh on 04/03/19.
//  Copyright © 2019 Codal Inc. All rights reserved.
//
import UIKit
/// It's used to add localization support for label that reflact directly via IB.
class CustomLabel: UILabel, LocalizationDelegate {
    // MARK:- Variables
    /// Used to prepare the file name based that we can find localization string in that file.
    private var _fileName: String?
    /// Used to prepare the localization key.
    private var _xibLocKey: String?
    /// Used to keep track of string has attribute or not.
    private var hasAttribute: Bool?
    /// Used prepare file name for the localization.
    @IBInspectable var fileName: String? {
        didSet {
            _fileName = fileName ?? ""
        }
    }
    /// Used to prepare the localization key.
    @IBInspectable var xibLocKey: String? {
        didSet {
            _xibLocKey = xibLocKey ?? ""
        }
    }
    /// Used prepare strings contain attribute.
    @IBInspectable var isAttributed: Bool = false {
        didSet {
            hasAttribute = isAttributed
        }
    }
    // MARK:- LifeCycle Methods
    /// Prepares the receiver for service after it has been loaded from an Interface Builder archive, or nib file.
    override func awakeFromNib() {
        super.awakeFromNib()
        translateTheText()
    }
    // MARK:- Functions
    /// It's used to translate the string based on file name and localization key.
    private func translateTheText() {
        if let fileName = _fileName {
            text = _xibLocKey?.localized(tableName: FileName(rawValue: fileName)!)
        }
    }
}
