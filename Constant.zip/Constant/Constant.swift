//
//  Constant.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

struct AppConstats {
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
}

struct AppConfigurationConstant {

    // MARK:- Variables
    /// class level variable that returns the current environment.
    static var currentEnvironment: Environment {
        var config = Configuration()
        return config.environment
    }
    /// It's used to get the access token.
    /// - Returns:
    /// - return the dictionary of type [String:String].
    static func accessToken() -> [String: String] {
        var headerInfo = [String: String]()
        headerInfo["Content-Type"] = "application/json"
        headerInfo["Authorization"] = SharedManager.shared.userInfo?.accessToken
        return headerInfo
    }
}

struct AppDateFormatter {
    static let ddMMYYYY = "dd/MM/yyyy"
    static let apiDatFormate = "yyyy-MM-dd"
}
