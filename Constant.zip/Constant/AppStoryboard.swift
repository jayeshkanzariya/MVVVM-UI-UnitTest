//
//  AppStoryboard.swift
//

import Foundation
import UIKit

/// enum that handle AppStoryboard related stuff.
/// Usage: let controller = LaunchViewController.instantiateFrom(appStoryboard: .Onboarding). Declare case for each new storyboard created.
enum AppStoryboard: String {
    // MARK:- App storyboard cases.
    case Main
    case SignUp
    case Login
    case DogLoverProfile
    case DogOwnerProfile
    case EditDogLoverProfile
    case EditDogOwnerProfile
    case Dashboard
    case Settings
    case Notification
    case VerificationProfile
    case Messages
    case Report
    
    // MARK:- Variables
    /// that returns instance of selected storyboard.
    var instance: UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
    }
    // MARK:- Functions
    /// that returns the current instace of view controller from current storyboard.
    func viewController<T: UIViewController>(viewControllerClass: T.Type) -> T {
        let storyboardId = (viewControllerClass as UIViewController.Type).storyboardID
        return instance.instantiateViewController(withIdentifier: storyboardId) as! T
    }
    /// that returns the instnace of current view controller.
    func initialViewController() -> UIViewController? {
        return instance.instantiateInitialViewController()
    }
}
