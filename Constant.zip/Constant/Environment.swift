//
//  Environment.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import Foundation
/// enum that is used to handle environments for application.
enum Environment: String {
    // MARK:- Environment cases.
    /// It's used for developement case.
    case development = "Development"
    /// It's used for production case.
    case production = "Production"
    /// It's used for stage case.
    case stage = "Stage"
    
    // MARK:- Variables
    /// that returns the current environment api URL.
    var apiUrl: String {
        switch self {
            case .development: return "https://apis.wannadoggy.es:8081"
            case .production: return "https://apis.wannadoggy.es:8081"
            case .stage: return "https://apis.wannadoggy.es:8081"
        }
    }
    
    /// that returns the current environment app store Link.
    var appStoreLink: String {
        switch self {
        default: return ""
        }
    }
    /// that returns the current enviroment first character.
    var enverionmentSymbol: String {
        switch self {
            case .development: return "D"
            case .production: return "P"
            case .stage: return "S"
        }
    }
    /// that returns the current environment privacy policy link..
    var electronicTermURL: URL {
        switch self {
          default:
            return URL(string:"http://3.18.206.205:5555/electronic-communications-agreement")!
        }
    }

    /// that returns the current environment privacy policy link..
    var privacyPolicyURL: URL {
        switch self {
            default:
                return URL(string:"http://3.18.206.205:5555/Privacy")!
        }
    }
    /// that returns the current environment privacy policy link..
    var termsURL: URL {
        switch self {
            default:
                return URL(string:"http://3.18.206.205:5555/Privacy")!
        }
    }
}
