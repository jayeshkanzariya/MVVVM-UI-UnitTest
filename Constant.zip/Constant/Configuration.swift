//
//  Configuration.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

import Foundation
/// It's a value type model that is used for environment configuration.
struct Configuration {
    /// It's used to get the environment.
    lazy var environment: Environment = {
        if let configuration = Bundle.main.object(forInfoDictionaryKey: "Configuration") as? String {
            if configuration.range(of: "Development") != nil {
                return Environment.development
            } else if configuration.range(of: "Production") != nil {
                return Environment.production
            } else if configuration.range(of: "Stage") != nil {
                return Environment.stage
            }
        }
        return Environment.production
    }()
}
