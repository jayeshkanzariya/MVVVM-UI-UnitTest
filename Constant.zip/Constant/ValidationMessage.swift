//
//  ValidationMessage.swift
//  WannaDogui
//
//  Created by codal on 30/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

struct ValidationMessage {

    static let emptyDogLoverAbout = "please enter some description about you."
    static let emptyDogLoverReason = "please enter reason why you like to spend time with dogs."
}
