//
//  DogProfileProvider.swift
//  WannaDogui
//
//  Created by Jayesh on 30/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit
import Moya

// the cases which use for manage the user related apis
enum DogProfileProvider {
    case loverProfile(params : [String:Any],images : [UIImage])
    case ownerProfile(params : [String:Any],images : [UIImage])
    case searchDogs(params : [String:Any])
    case searchDogLovers(params : [String:Any])
    case addToFavourite(params : [String:Any])
    case favouriteList(params : [String:Any])
    
}

extension DogProfileProvider : TargetType {
    
    // that is used get the base url
    var baseURL: URL {
        return "\(AppConfigurationConstant.currentEnvironment.apiUrl)/dog/".toUrl
    }
    
    // that is used get the path for the request
    var path: String {
        switch self {
            case .loverProfile: return "lover-profile"
            case .ownerProfile: return "owner-profile"
            case .searchDogs: return "search-dogs"
            case .searchDogLovers: return "search-dog-lovers"
            case .addToFavourite: return "favourite"
            case .favouriteList : return "favourite-list"
        }
    }
    
    // that is used get the method for the request
    var method: Moya.Method {
        switch self {
            case .loverProfile: return .post
            case .ownerProfile: return .post
            case .searchDogs: return .post
            case .searchDogLovers: return .post
            case .addToFavourite: return .post
            case .favouriteList : return .post
        }
    }
    
    // that is used get the sample data for the request
    var sampleData: Data {
        return Data()
    }
    
    // that is used get task based on selected account user
    var task: Task {
        switch self {
            case .loverProfile(let params,let images):
                var formData: [Moya.MultipartFormData] = []
                for (key, value) in params {
                    let val = String(describing: value).data(using: .utf8) ?? Data()
                    formData.append(MultipartFormData(provider: .data(val), name: key))
                }
                for (index,image) in images.enumerated() {
                    let imageData = image.jpegData(compressionQuality: 1.0)
                    formData.append(Moya.MultipartFormData(provider: .data(imageData!), name: "photos", fileName: "\(Date().timeIntervalSince1970)\(index).jpeg", mimeType: "image/jpeg"))
                }
                return .uploadMultipart(formData)
        case .ownerProfile(let params,let images):
            var formData: [Moya.MultipartFormData] = []
            for (key, value) in params {
                let val = String(describing: value).data(using: .utf8) ?? Data()
                formData.append(MultipartFormData(provider: .data(val), name: key))
            }
            for (index,image) in images.enumerated() {
                let imageData = image.pngData()
                //jpegData(compressionQuality: 1.0)
                formData.append(Moya.MultipartFormData(provider: .data(imageData!), name: "photos", fileName: "\(Date().timeIntervalSince1970)\(index).jpeg", mimeType: "image/jpeg"))
            }
            return .uploadMultipart(formData)
        case .searchDogs(params: let params):
            return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        case .searchDogLovers(params: let params):
            return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        case .addToFavourite(params: let params):
            return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        case .favouriteList(params: let params):
            return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        }
    }
    
    // that is used for getting header
    var headers: [String : String]? {
        return AppConfigurationConstant.accessToken()
    }
    
}



