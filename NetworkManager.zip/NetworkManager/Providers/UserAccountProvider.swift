//
//  UserProvider.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit
import Moya

// the cases which use for manage the user related apis
enum UserAccountProvider {
    case login(params : [String:Any])
    case createUser(params : [String:Any])
    case forgotPassword(params : [String:Any])
    case updateNotificationPreferences(params : [String:Any])
    case editProfile(params : [String:Any])
    case changePassword(params : [String:Any])
    case logout(params : [String:Any])
    case sendVerificationOtp(params : [String:Any])
    case verifyOtp(params : [String:Any])
    case viewProfileNotification(params : [String:Any])
    case getUserProfile(params : [String:Any])
    case validateReceipt(params : [String:Any])
    case checkIsPremiumUserOrnot(params : [String:Any])
    case reportUser(params : [String:Any])
    
}

extension UserAccountProvider : TargetType {
    
    // that is used get the base url
    var baseURL: URL {
        return "\(AppConfigurationConstant.currentEnvironment.apiUrl)/users/".toUrl
    }
    
    // that is used get the path for the request
    var path: String {
        switch self {
            case .createUser: return "sign-up"
            case .forgotPassword: return "forgot-password"
            case .login: return "login"
            case .updateNotificationPreferences: return "update-notification-preferences"
            case .editProfile:return "edit-profile"
            case .changePassword:return "change-password"
            case .logout:return "logout"
            case .sendVerificationOtp: return "send-verification-otp"
            case .verifyOtp: return "verify-otp"
            case .viewProfileNotification : return "view-profile-notification"
            case .getUserProfile : return "profile"
            case .validateReceipt: return "in-app-purchase"
            case .checkIsPremiumUserOrnot : return "validate-in-app-subscription"
            case .reportUser : return "report"
        }
    }
    
    // that is used get the method for the request
    var method: Moya.Method {
        switch self {
            case .createUser: return .post
            case .forgotPassword: return .post
            case .login : return .post
            case .updateNotificationPreferences: return .post
            case .editProfile: return .post
            case .changePassword: return .post
            case .logout: return .post
            case .sendVerificationOtp: return .post
            case .verifyOtp: return .post
            case .viewProfileNotification : return .post
            case .getUserProfile : return .post
            case .validateReceipt: return .post
            case .checkIsPremiumUserOrnot : return .post
            case .reportUser : return .post
        }
    }
    
    // that is used get the sample data for the request
    var sampleData: Data {
        return Data()
    }
    
    // that is used get task based on selected account user
    var task: Task {
        switch self {
            case .createUser(let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .forgotPassword(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .login(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .updateNotificationPreferences(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .editProfile(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .changePassword(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .logout(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
             case .sendVerificationOtp(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
             case .verifyOtp(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .viewProfileNotification(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .getUserProfile(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .validateReceipt(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .checkIsPremiumUserOrnot(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
            case .reportUser(params: let params): return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        }
    }
    
    // that is used for getting header
    var headers: [String : String]? {
        return AppConfigurationConstant.accessToken()
    }
    
}
