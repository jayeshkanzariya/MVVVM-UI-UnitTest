//
//  FirebaseProvider.swift
//  WannaDoggy
//
//  Created by Jayesh on 14/11/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit
import Moya

enum FirebaseProvider {
    case onlineUser(params : [String:Any])
}

extension FirebaseProvider : TargetType {
    
    // that is used get the base url
    var baseURL: URL {
        return "https://us-central1-wannadoggy.cloudfunctions.net/".toUrl
    }
    
    // that is used get the path for the request
    var path: String {
        switch self {
            case .onlineUser: return "userPresenceUpdate"
        }
    }
    
    // that is used get the method for the request
    var method: Moya.Method {
        switch self {
            case .onlineUser: return .get
        }
    }
    
    // that is used get the sample data for the request
    var sampleData: Data {
        return Data()
    }
    
    // that is used get task based on selected account user
    var task: Task {
        switch self {
        case .onlineUser(let params): return .requestParameters(parameters: params, encoding: URLEncoding.queryString)
        }
    }
    
    // that is used for getting header
    var headers: [String : String]? {
        return nil
    }
    
}


