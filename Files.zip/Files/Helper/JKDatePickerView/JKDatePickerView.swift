//
//  CustomDataPickerView.swift
//  YogaCover
//
//  Created by Jayesh on 25/12/16.
//  Copyright © 2016 JK Infotech. All rights reserved.
//

import UIKit

class JKDatePickerView: UIView {
    
    @IBOutlet var btndone : UIButton!
    @IBOutlet var btncancel : UIButton!
    @IBOutlet var datepicker : UIDatePicker!
    @IBOutlet var bottomconstraint : NSLayoutConstraint!
    
    typealias Pickercomplition = (_ seldate : Date) -> ()
    var datecomplition:Pickercomplition!
    
    class func showPicker(color : UIColor,datePickerMode : UIDatePicker.Mode,completion : @escaping Pickercomplition) -> JKDatePickerView{
        let view = Bundle.main.loadNibNamed("JKDatePickerView", owner: nil, options: nil)?[0] as! JKDatePickerView
        view.datecomplition = completion
        view.backgroundColor = color
        view.datepicker.locale = Locale(identifier: "en_GB")
        view.datepicker.datePickerMode = datePickerMode
        view.datepicker.maximumDate = Date()
        return view
    }
    func  animatedpickerview(){
        
    }
    func hidepickerview(){
        UIView.animate(withDuration: 0.3, animations: {
            self.layoutIfNeeded()
        }) { (flg) in
            UIView.animate(withDuration: 0.3, animations: {
                }, completion: { (true) in
                self.removeFromSuperview()
            })
        }
    }
    
    @IBAction func onclickdone(sender : AnyObject!){
        datecomplition(datepicker.date)
        hidepickerview()
    }
    
    @IBAction func onclickCancel(sender : AnyObject!){
        hidepickerview()
    }
    
    @IBAction func valueChanged(sender : UIDatePicker){
        datecomplition(datepicker.date)
    }
}



