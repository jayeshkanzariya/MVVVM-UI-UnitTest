//
//  SocialLogin.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import AuthenticationServices

class SocialLoginManager : NSObject {

    static let shared = SocialLoginManager()
    
    let faceBook = LoginManager()
    
    var successLoginWithApple : ((ASAuthorizationAppleIDCredential) -> ())?
    var errorInLoginWithApple : ((String) -> ())?
    
    private override init() {  }
    
    func loginWithFacebook(success : @escaping ((Any?) -> ()),failure : @escaping ((String) -> ()),cancelled : @escaping (() -> ())) {
        
        faceBook.logIn(permissions: ["public_profile", "email"], from: nil) { (result, error) in
            if let result = result,result.isCancelled {
                cancelled()
            }
            else if error != nil
            {
                failure(error!.localizedDescription)
                self.faceBook.logOut()
            }
            else if let result = result, result.grantedPermissions.contains("public_profile") {
                let graphRequest = GraphRequest(graphPath: "me", parameters: ["fields" : "id,name,email,age_range,gender,picture"])
                let connection = GraphRequestConnection()
                connection.add(graphRequest, completionHandler: { (connection, info , error) in
                    ProgressIndicatorManager.shared.dismiss()
                    if error != nil
                    {
                        failure(error!.localizedDescription)
                    }
                    else
                    {
                        success(info)
                        self.faceBook.logOut()
                   }
                })
                connection.start()
            }
                
            else
            {
                self.faceBook.logOut()
            }
        }
    }
    
    func loginWithApple(success : @escaping ((ASAuthorizationAppleIDCredential) -> ()),failure : @escaping ((String) -> ())) {
        if #available(iOS 13.0, *) {
            self.successLoginWithApple = success
            self.errorInLoginWithApple = failure
            let appleIDProvider = ASAuthorizationAppleIDProvider()
            let idRequest = appleIDProvider.createRequest()
            
            idRequest.requestedScopes = [.fullName, .email]
//            let passwordRequest = ASAuthorizationPasswordProvider().createRequest()
            
            
            let authorizationController = ASAuthorizationController(authorizationRequests: [idRequest])
            authorizationController.delegate = self
            authorizationController.presentationContextProvider = self
            authorizationController.performRequests()
        } else {
            
        }
    }
}

extension SocialLoginManager :ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
   
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return (UIApplication.shared.delegate as! AppDelegate).window!
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        errorInLoginWithApple?(error.localizedDescription)
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        successLoginWithApple?(authorization.credential as! ASAuthorizationAppleIDCredential)
    }
}

 
