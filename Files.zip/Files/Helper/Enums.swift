//
//  Enums.swift
//  WannaDogui
//
import Foundation
import UIKit
import AuthenticationServices
// MARK:- it is useful for slide option

enum IntroductionSlider : Int,CaseIterable {
    
    case first = 0
    case second
    case third
    case fourth
    
    var image : UIImage? {
        switch self {
            case .first:
                return #imageLiteral(resourceName: "img_introfirst")
            case .second:
                return   #imageLiteral(resourceName: "img_introsecond")
            case .third:
                return #imageLiteral(resourceName: "img_introthird")
            case .fourth:
                return #imageLiteral(resourceName: "img_introfourth")
        }
    }
    
    var description : String? {
        switch self {
            case .first:
                return "Connecting dog owners with local dog lovers for walks, company,weekends or holidays."
            case .second:
                return  "Bringing together people who have a dog and need extra help, with people who do not own a dog but occasionally want to look after one and dogs that love company and playtime"
            case .third:
                return "Create your profile, share photos, add your availability to start browsing lovely dogs or dog lovers in your area."
            case .fourth:
                return "Subscribe to chat, meet-up, and start sharing the company of dogs with verified users with the benefit of third party insurance and access to 24/7 Vet line"
        }
    }
}

enum UserType : String, Codable {
    case dogOwner = "1"
    case dogLover = "2"
}

enum SignUpAccountOption {
    case facebook([String : Any])
    case apple(ASAuthorizationAppleIDCredential)
    case email
}

// Dog Owner Profile Option
enum PreviousDogExperiance : Int,CaseIterable {
    
    case DogOwner = 1
    case DogWalker
    case WithFamilyFriendDogs
    
    var title : String  {
        switch self {
            case .DogOwner:
                return "As a Dog Owner"
            case .DogWalker:
                return "As a Dog Walker"
            case .WithFamilyFriendDogs:
                return "With Family/Friends Dog"
        }
    }
    
    static var icon : UIImage? {
        return UIImage(named: "icn_doglover_experiance")
    }
    
    static func values(ids : String) -> String {
        let values = ids.components(separatedBy: ",")
        var options : [String] = []
        for value in values {
            if let val = Int(value), let type = PreviousDogExperiance(rawValue :val) {
                options.append(type.title)
            }
        }
        return options.joined(separator: ",")
    }
}

enum DogSizeOption : Int,CaseIterable {
    
    case Small = 1
    case Medium
    case Large
    
    var title : String  {
        switch self {
            case .Small:
                return "Small"
            case .Medium:
                return "Medium"
            case .Large:
                return "Large"
        }
    }
    
}

enum DogOwnerAvailibityOption : Int,CaseIterable {

    case WeekDaysDayTime = 1
    case weekDaysEvening
    case Weekends
    case HolidaysOrOVerNightStays
    
    var title : String  {
        switch self {
            case .WeekDaysDayTime:
                return "Weekdays - daytime"
            case .weekDaysEvening:
                return "Weekdays - evening"
            case .Weekends:
                return "Weekends"
            case .HolidaysOrOVerNightStays:
                return "Holidays or overnight stays"
        }
    }
    
    static var icon : UIImage? {
        return UIImage(named: "icn_doglover_availibility")
    }

    
    static func values(ids : String) -> String {
        let values = ids.components(separatedBy: ",")
        var options : [String] = []
        for value in values {
            if let val = Int(value), let type = DogOwnerAvailibityOption(rawValue :val) {
                options.append(type.title)
            }
        }
        return options.joined(separator: ",")
    }
    
}

enum DogGetWellWithOption : Int,CaseIterable {

    case Children = 1
    case OtherDogs
    case Cats
    
    var title : String  {
        switch self {
            case .Children:
                return "Children"
            case .OtherDogs:
                return "Other Dogs"
            case .Cats:
                return "Cats"
        }
    }
    
    static var icon : UIImage? {
        return UIImage(named: "icn_well_with")
    }
    
    static func values(ids : String) -> String {
        let values = ids.components(separatedBy: ",")
        var options : [String] = []
        for value in values {
            if let val = Int(value), let type = DogGetWellWithOption(rawValue :val) {
                options.append(type.title)
            }
        }
        return options.joined(separator: ",")
    }
    
}

enum DogLikeOption : Int,CaseIterable {

    case Exercise = 1
    case DogSitting
    case BathGrooming
    case LoveAndCuddles
    
    var title : String  {
        switch self {
            case .Exercise:
                return "Exercise (Walks / Playtime)"
            case .DogSitting:
                return "Dog Sitting"
            case .BathGrooming:
                return "Bath & Grooming"
            case .LoveAndCuddles:
                return "Love and Cuddles"
        }
    }
    
    static func values(ids : String) -> String {
        let values = ids.components(separatedBy: ",")
        var options : [String] = []
        for value in values {
            if let val = Int(value), let type = DogLikeOption(rawValue :val) {
                options.append(type.title)
            }
        }
        return options.joined(separator: ",")
    }
    
    static var icon : UIImage? {
        return UIImage(named: "icn_dog_like")
    }
    
}


enum SideMenuOptions : Int,CaseIterable {

    case ProfileHeader = 0
    case Profile
    case Messages
    case Favourites
    case Notifications
    case Settings
    case Help
    case Logout
    
    var title : String {
        switch self {
            case .Profile:
                return "Profile"
            case .Messages:
                return "Messages"
            case .Favourites:
                return "Favourites"
            case .Settings:
                return "Settings"
            case .Notifications:
                return "Edit Notifications"
            case .Help:
                return "Help"
            case .Logout:
                return "Sign out"
            default:
                return ""
        }
    }
    
    var icon : UIImage? {
        switch self {
            case .Profile:
                return UIImage(named: "icn_dog_profile")
            case .Messages:
                return UIImage(named: "icn_message")
            case .Favourites:
                return UIImage(named: "icn_favourites")
            case .Notifications:
                return UIImage(named: "icn _edit_notification")
            case .Settings:
                return UIImage(named: "icn_settings")
            case .Help:
                return UIImage(named: "icn_help")
            default:
                return nil
        }
    }
}

// MARK:- use for flter option
enum FilterListOption : Int,CaseIterable {
    case Availibility = 1
    case Location
    case Verification
    case SizeOfDog
    case DogBreeding
    
    var title : String {
        switch self {
            case .Availibility:
                return "Availability"
            case .Location:
                return "Location"
            case .Verification:
                return "Verification"
            case .SizeOfDog:
                return "Size of Dog"
            case .DogBreeding:
                switch SharedManager.shared.userInfo?.userType {
                    case .dogLover:
                        return "Dog Breeding"
                    case .dogOwner:
                        return "Breed Of Dog"
                    case .none:
                        return "Dog Breeding"
                }
                
        }
    }
    
    var icon : UIImage? {
        switch self {
            case .Availibility:
                return UIImage(named: "icn_filter_availability")
            case .Location:
                return UIImage(named: "icn_filter_location")
            case .Verification:
                return UIImage(named: "icn - filter - verified")
            case .SizeOfDog:
                return UIImage(named: "icn_filter_dog_size")
            case .DogBreeding:
                return UIImage(named: "icn_filter_dogbreeding")
        }
    }
    
    var parameterName : String {
        switch self {
            case .Availibility:
                return "availability"
            case .Location:
                return "distance"
            case .Verification:
                return "verified"
            case .SizeOfDog:
                return "size"
            case .DogBreeding:
                return "Dog Breeding"
        }
    }
}


// MARK:- Notification Type for Dog Lover
enum NotificationType : CaseIterable {
    case WeeklyNewUserUpdates
    case ReadNotify
    case FavouriteNotify
    
    var title : String {
        switch self {
            case .WeeklyNewUserUpdates:
                return "Weekly updates in your area (new dogs)"
            case .ReadNotify:
                return "Receive email when someone has read my profile"
            case .FavouriteNotify:
                return "Receive email when someone liked my profile"
        }
    }
}
