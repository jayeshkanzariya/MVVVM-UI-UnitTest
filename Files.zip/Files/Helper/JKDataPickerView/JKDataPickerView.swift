//
//  JKDataPickerView.swift

//  Created by Jayesh on 25/12/16.
//  Copyright © 2016 JK Infotech. All rights reserved.
//

import UIKit

class JKDataPickerView: UIView {

    @IBOutlet var btndone : UIButton!
    @IBOutlet var btncancel : UIButton!
    var arrTitle : [[String]] = []
    @IBOutlet var pickerView : UIPickerView!
    @IBOutlet var mainView : UIView!
    
    typealias Pickercomplition = (Int,_ seltitle : String) -> ()
    var datacomplition:Pickercomplition!
    
    class func showPicker(color : UIColor? = nil,titlearr : [[String]],mainview : UIView,completion : @escaping Pickercomplition) -> JKDataPickerView{
        let view : JKDataPickerView = JKDataPickerView.fromNib()
            //Bundle.main.loadNibNamed("CustomDataPickerView", owner: self, options: nil)?[0] as! JKDataPickerView
        view.datacomplition = completion
        view.backgroundColor = UIColor.darkGray
        view.arrTitle = titlearr
        view.pickerView.reloadAllComponents()
        return view
    }
    
    func hidepickerview(){
        UIView.animate(withDuration: 0.3, animations: {
            self.layoutIfNeeded()
        }) { (flg) in
            UIView.animate(withDuration: 0.3, animations: {
            }, completion: { (true) in
                self.removeFromSuperview()
            })
        }
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
extension JKDataPickerView : UIPickerViewDataSource,UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrTitle[component].count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        datacomplition(row,arrTitle[component][row])
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrTitle[component][row]
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return arrTitle.count
    }
}
