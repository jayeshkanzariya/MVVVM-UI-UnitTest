//
//  LocationManager.swift
//  Gr8dish
//
//  Created by Jayesh on 25/11/18.
//  Copyright © 2018 Jayesh kanzariya. All rights reserved.
//

import UIKit
import CoreLocation

class LocationManager: NSObject {

    static let sharedInstance = LocationManager()
    var locationManger : CLLocationManager?
    var currentLocation : CLLocation?
    var locationPermission : ((_ status : CLAuthorizationStatus)->())?
        
    private override init() {
        super.init()
        locationManger = CLLocationManager()
        locationManger?.delegate = self
    }
    
    @discardableResult
    func checkAuthorizationStatus() -> Bool {
        switch CLLocationManager.authorizationStatus(){
        case .authorizedWhenInUse:
            print("Allow")
            return true
        case .denied:
            print("Deny")
            return false
        case .restricted:
            print("restricted")
            return false
        case .authorizedAlways:
            print("restricted")
            return false
        case .notDetermined:
            print("Not Determine")
            return false
        @unknown default:
            fatalError()
        }
    }
    
    func requestForLocationWhenInUse() {
        locationManger?.requestWhenInUseAuthorization()
    }
    func requestForAlwaysAuthorization(){
        locationManger?.requestAlwaysAuthorization()
    }
    
    func startUpdatingLocation(){
        locationManger?.delegate = self
        locationManger?.startUpdatingLocation()
    }
    
    func startUpdateLocationWithSignificationChnage() {
        locationManger?.delegate = self
        locationManger?.startUpdatingLocation()
        locationManger?.startMonitoringSignificantLocationChanges()
    }
    
    func stopUpdatingLocation(){
        locationManger?.stopUpdatingLocation()
        locationManger?.stopMonitoringSignificantLocationChanges()
    }
    
    func getCountryCodeFromLocation(location : CLLocation,complitionHandler : @escaping ((_ countryCode : String)->()),erroHandler : @escaping ((_ error : String) -> ())){
        // Look up the location and pass it to the completion handler
        CLGeocoder().reverseGeocodeLocation(location) { (placeMark, error) in
            if error != nil{
               erroHandler(error?.localizedDescription ?? " not able to get country code")
            }
            else if let placemark = placeMark?.first{
                complitionHandler(placemark.isoCountryCode ?? "")
            }
        }

    }
    
    
}

extension LocationManager : CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            print("Current Location : \(location)")
            currentLocation = location
            stopUpdatingLocation()
        }
    }
    
    func locationManagerDidPauseLocationUpdates(_ manager: CLLocationManager) {
        
    }
    
    func locationManagerDidResumeLocationUpdates(_ manager: CLLocationManager) {
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager fail with error\(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        locationPermission?(status)
    }
}
