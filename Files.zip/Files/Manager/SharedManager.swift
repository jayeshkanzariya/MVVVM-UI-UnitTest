//
//  SharedManager.swift
//  WannaDogui
//
//  Created by Jayesh on 18/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

class SharedManager: NSObject {

    static let shared = SharedManager()
    
    var userInfo : UserInformationModel?
    var arrBreedType = [BreedTypeModel]()
    
    private override init() {
        
    }
    
}
