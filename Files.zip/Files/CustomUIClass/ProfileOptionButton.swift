//
//  ProfileOptionButton.swift
//  WannaDogui
//
//  Created by codal on 30/06/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

class ProfileOptionButton: UIButton {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.setTitleColor(.black, for: .selected)
        self.setTitleColor(.black, for: .normal)
        self.titleLabel?.font = UIFont.quickSandRegular(size: 14.0)
        self.contentEdgeInsets = UIEdgeInsets(top: 15, left: 0, bottom: 15, right: 0)
        self.frame.size.height = 50
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
        
    }
   
    override var isSelected: Bool {
        didSet {
            self.setTitleColor(.black, for: .normal)
            self.setTitleColor(.black, for: .selected)
            self.tintColor = .clear
            if isSelected {
                self.backgroundColor = UIColor(hex: "1DBF73").withAlphaComponent(0.2)
            }
            else {
                self.backgroundColor = UIColor(hex: "F4F4F4")
            }
        }
    }
}

