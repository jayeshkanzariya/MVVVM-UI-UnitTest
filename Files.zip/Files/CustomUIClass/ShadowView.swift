//
//  ShadowView.swift
//  Spendwitty
//
//  Created by Jayesh on 23/07/19.
//  Copyright © 2019 Jayesh. All rights reserved.
//

import UIKit

/**
    This Protocol is used for adding shadow on view
 */
protocol ShadowViewProtocol : class {
    func dropShadow(cornerRadius:CGFloat,opacity : Float,color : UIColor,radius : CGFloat)
    func addGradiant(colours : [UIColor],loactions : [NSNumber],startPoint : CGPoint,endPoint : CGPoint)
}

extension ShadowViewProtocol where Self : UIView {
    
    /**
        This method is used for adding shadow on view
    */
    func dropShadow(cornerRadius:CGFloat,opacity : Float,color : UIColor,radius : CGFloat) {
        self.layer.masksToBounds = false
        self.layer.cornerRadius = cornerRadius
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius / 2.0
        self.layer.shadowPath = nil
    }
    
    /**
     This method is used for adding Gradiant Layer
     */
    func addGradiant(colours : [UIColor],loactions : [NSNumber],startPoint : CGPoint,endPoint : CGPoint) {
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.frame = self.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.locations = loactions
        gradient.startPoint = startPoint
        gradient.endPoint = endPoint
        self.layer.insertSublayer(gradient, at: 0)
    }
}

