//
//  CustomUIClass.swift
//

import UIKit

// Use For the Round Button
class RoundLabel: UILabel {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
}

// Use For the Round Button
class RoundButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
}


// Use For the Round Imageview
class RoundImageView : UIImageView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
}

// Use For the Round shadow Imageview
class RoundShadowImageView : UIImageView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        let shadowPath = UIBezierPath(rect: self.bounds)
        self.layer.shadowRadius = self.frame.size.height / 2
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowOpacity = 1.0
        self.layer.shadowPath = shadowPath.cgPath
        self.layer.shadowColor = UIColor.black.cgColor
    }
}

// Use Fot the RoundView
class RoundView : UIView{
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
}

// Custom Progress View
class CustomProgressView : UIProgressView {
    
    override func layoutSubviews() {
        super.layoutSubviews()

        let maskLayerPath = UIBezierPath(roundedRect: bounds, cornerRadius: 4.0)
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path = maskLayerPath.cgPath
        layer.mask = maskLayer
    }
}

class ShadowView : UIView{
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        DispatchQueue.main.async {
            self.applyShadow()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        DispatchQueue.main.async {
            self.applyShadow()
        }
    }
    
    func applyShadow(){
        self.layer.shadowRadius = 15 / 2.0
        self.layer.masksToBounds = false
        self.layer.shadowOffset = .zero
        self.layer.shadowOpacity = 0.1
        self.layer.shadowColor = UIColor.black.cgColor
    }
}

class RoundWithShadowButton : UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        DispatchQueue.main.async {
            self.applyShadow()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        DispatchQueue.main.async {
            self.applyShadow()
        }
    }
    
    func applyShadow(){
        self.layer.cornerRadius = self.layer.frame.size.height / 2
        self.layer.shadowRadius = 26 / 2
        self.layer.masksToBounds = false
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.layer.shadowOpacity = 0.6
        self.layer.shadowColor = UIColor(hex: "#C6C6C6").cgColor
    }
}
