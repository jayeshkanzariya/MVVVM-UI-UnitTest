//
//  SignUpNavigationController.swift
//  FlipScrore
//
//  Created by Jayesh on 30/04/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

class DashboardNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpController()
        // Do any additional setup after loading the view.
    }
    
    private func setUpController() {
        self.navigationItem.titleView = UIImageView(image: #imageLiteral(resourceName: "navbar_background"))
        navigationBar.isTranslucent = false
        navigationBar.setBackgroundImage(#imageLiteral(resourceName: "navbar_background"), for: .default)
        navigationBar.shadowImage = UIImage()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
