
//
//  UIColorExtension.swift
//  FlipScrore
//
//   Created by Pircle on 15/05/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

extension UIColor {
    
    class func themeColor() -> UIColor {
        return #colorLiteral(red: 0.1137254902, green: 0.7490196078, blue: 0.4509803922, alpha: 1)
    }
    
    class func textColor() -> UIColor {
        return #colorLiteral(red: 0.1215686275, green: 0.1098039216, blue: 0.1098039216, alpha: 1)
    }
}
