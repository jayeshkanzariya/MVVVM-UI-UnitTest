//
//  DoubleExtension.swift
//  WannaDogui
//
//  Created by Jayesh on 25/08/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

extension Double {

    func toString() -> String {
        return String(self)
    }
}
