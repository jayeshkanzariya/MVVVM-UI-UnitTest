//
//  DTTextFieldExtension.swift
//  FlipScrore
//
////   Created by Pircle on 02/06/20.
////  Copyright © 2020 Jayesh kanzariya. All rights reserved.
////
//
//import UIKit
//import DTTextField
//
//extension DTTextField {
//    
//    func configureTextfield() {
//        self.borderStyle = .line
//        self.dtborderStyle = .bottom
//        self.canShowBorder = true
//        self.floatPlaceholderFont = UIFont.regularMontserrat(size: 14.0)
//        self.floatPlaceholderActiveColor = UIColor.themeColor()
//        self.floatPlaceholderColor = UIColor.themeColor()
//        self.borderColor = UIColor(hex: "E4E4E4")
//        self.paddingYFloatLabel = 5
//        self.errorFont = UIFont.regularMontserrat(size: 12.0)
//    }
//}
