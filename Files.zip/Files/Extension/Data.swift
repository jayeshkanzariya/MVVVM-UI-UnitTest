////
////  Data.swift
////  Muze
////
import Foundation
import ObjectMapper
import Moya_ObjectMapper
import Moya
/// Extension of `Data` that is used to extend the functions and properties.
extension Data {
    /// It's used to convert JSON response of error to error model.
    /// - Returns:
    ///     - returns the instance of `AppError`.
    
    func decodeData<T:Codable>() throws -> T{
        do{
            let decode = try JSONDecoder().decode(T.self, from: self)
            return decode
        }
        catch(let error) {
            print(error.localizedDescription)
            throw error
        }
    }
    
//    func convertToError() -> AppError {
//        do {
//            let json = try JSONSerialization.jsonObject(with: self, options: []) as? [String : Any]
//            if let json = json {
//                let mappedError = Mapper<AppError>().map(JSON: json)!
//                return mappedError
//            } else {
//                return Mapper<AppError>().map(JSON: ["Message": "Something went wrong..."])!
//            }
//        } catch {
//            return Mapper<AppError>().map(JSON: ["Message": error.localizedDescription])!
//        }
//    }
    /// computed propery the is used to get hexadecimal string.
    public var hexadecimalString: String {
        var bytes = [UInt8](repeating: 0, count: count)
        copyBytes(to: &bytes, count: count)
        let hexString = NSMutableString()
        for byte in bytes {
            hexString.appendFormat("%02x", UInt(byte))
        }
        return String(hexString)
    }
}
