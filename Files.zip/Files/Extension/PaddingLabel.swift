//
//  PaddingLabel.swift
//  Streamliss
//
//  Created by Jayesh on 07/10/18.
//  Copyright © 2018 ActiveLogic Labs. All rights reserved.
//

import UIKit

// MARK:- CustomLabel Class For padding in Label
class PaddingLabel: RoundLabel {
    let insets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: insets))
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
    }
    
    override var intrinsicContentSize: CGSize{
        var contentSize = super.intrinsicContentSize
        contentSize.height += insets.top + insets.bottom
        contentSize.width += insets.left + insets.right
        return CGSize(width: contentSize.width, height: contentSize.height)
    }
}

