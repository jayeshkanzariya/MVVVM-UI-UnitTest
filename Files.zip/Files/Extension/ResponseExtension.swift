////
////  ResponseExtension.swift
////  Muze
////
//import Foundation
//import ObjectMapper
//import Moya_ObjectMapper
//import Moya
///// Extension of `Response` that is used to extend the functions and properties.
//extension Response {
//    /// It's used to convert JSON response of error to error model.
//    /// - Returns:
//    ///     - returns the instance of `AppError`.
//    func convertToError() -> StatusModel {
//        do {
//            let json = try JSONSerialization.jsonObject(with: self.data, options: []) as? [String : Any]
//            if let json = json {
//                let mappedError = Mapper<StatusModel>().map(JSON: json)!
//                handleGlobalError(statusCode: self.statusCode)
//               // mappedError.statusCode = self.statusCode
//                return mappedError
//            } else {
//                return Mapper<StatusModel>().map(JSON: ["Message": "Something went wrong..."])!
//            }
//        } catch {
//            return Mapper<StatusModel>().map(JSON: ["Message": error.localizedDescription])!
//        }
//    }
//    /// It's used to handle the global error.
//    /// - Parameters:
//    ///     - statusCode: An instance of `Int` that is used for status code.
//    func handleGlobalError(statusCode: Int) {
//        if statusCode == 401 {
//            print("Error")
//        }
//    }
//}
