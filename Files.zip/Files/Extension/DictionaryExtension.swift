//
//  DictionaryExtension.swift
//  Muze
//
import Foundation
/// Extension of `Dictionary` that is used to extend the functions and properties.
extension Dictionary {
    /// It's used to get key value seperated pair for given index.
    /// - Parameters:
    ///     - i: instance of `Int` that is used for index.
    /// - Returns:
    ///     - return the tuple inform of key and value separated.
    subscript(i: Int) -> (key: Key, value: Value) {
        return self[index(startIndex, offsetBy: i)]
    }
}
