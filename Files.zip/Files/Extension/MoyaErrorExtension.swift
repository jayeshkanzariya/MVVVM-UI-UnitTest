////
////  MoyaErrorExtension.swift
////  Muze
////
//
//import Foundation
//import ObjectMapper
//import Moya
///// Extension of `MoyaError` that is used to extend the functions and properties.
//extension MoyaError {
//    /// It's used to convert JSON response to error model.
//    /// - Returns:
//    ///     - retuns the instance of `AppError`.
//    func convertToError() -> StatusModel {
//        return Mapper<StatusModel>().map(JSON: ["Message": self.localizedDescription])!
//    }
//}
