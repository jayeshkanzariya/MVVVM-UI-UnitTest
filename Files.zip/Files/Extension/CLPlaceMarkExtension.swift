//
//  CLPlaceMarkExtension.swift
//  Muze
//
import MapKit

extension CLPlacemark {
    
    func getAddress() -> String {
        
        let firstSpace = (subThoroughfare != nil && thoroughfare != nil) ? " " : ""
        let comma = (subThoroughfare != nil || thoroughfare != nil) && (subAdministrativeArea != nil || administrativeArea != nil) ? ", " : ""
        let secondSpace = (subAdministrativeArea != nil && administrativeArea != nil) ? " " : ""
        let addressLine = String(
            format:"%@%@%@%@%@%@%@",
            subThoroughfare ?? "",
            firstSpace,
            thoroughfare ?? "",
            comma,
            locality ?? "",
            secondSpace,
            administrativeArea ?? ""
        )
        return addressLine
    }
}
