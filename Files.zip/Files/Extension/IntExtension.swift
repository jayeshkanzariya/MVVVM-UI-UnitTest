//
//  IntExtension.swift
//  FlipScrore
//
//   Created by Pircle on 13/05/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

extension Int {
    
    func toString() -> String? {
        return String(self)
    }
    
    func toBool() -> Bool {
        if self >= 1 {
            return true
        }
        else {
            return false
        }
    }
}
