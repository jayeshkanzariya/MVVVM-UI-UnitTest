//
//  String.swift

import Foundation
import UIKit

/// Extension of `String` that is used to extend the functions and properties.
extension String {
    /// that returns the instace of `URL`
    var toUrl: URL {
        return URL(string: self)!
    }
    /// It's used to get given string is matches or not.
    /// - Parameters:
    ///     - regex: instace of `String` that is used for string comparision.
    /// - Returns:
    ///     - instace of `Bool`
    func matches(regex: String) -> Bool {
        return self.range(of: regex, options: .regularExpression, range: nil, locale: nil) != nil
    }
    /// It's used to identify string is empty or not.
    /// - Returns:
    ///     - returns the instace of  `Bool`.
    func isEmptyString() -> Bool {
       return self.count <= 0 || self.trimmingCharacters(in: .whitespaces).count <= 0
    }
    /// It's used to identify email is valid or not.
    /// - Returns:
    ///     - returns the instace of  `Bool`.
    func isValidEmail() -> Bool {
           let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
           return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
       }
//    /// It's used to map the string into model.
//    /// - Returns:
//    ///     - returns the mappable object model.
//    func mapToModel<T: Mappable>() -> T {
//        return Mapper<T>().map(JSONString: self)!
//    }
    /// It's used to trim white spaces and newlines.
    /// - Returns:
    ///     - returns instance of `String` that is trimmed string.
    func trim() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    /// It's used to convert string to date for given formater.
    /// - Parameters:
    ///     - format: instace of `String` that is for format and default value is `yyyy-MM-dd'T'hh:mm:ss`.
    /// - Returns:
    ///     - returns ithe nstance of `Date` that is formated date instance.
    func toDate(format: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = .current
        dateFormatter.dateFormat = format
        return dateFormatter.date(from: self)
    }
    /// It's used to convert string to date for given formater.
    /// - Parameters:
    ///     - format: instace of `String` that is for format and default value is `d MMM yyyy`.
    /// - Returns:
    ///     - returns ithe nstance of `Date` that is formated date instance.
    func toShortDate(format: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.date(from: self)
    }
    
    func getAgeFromDOB() -> String {
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = "MM/dd/yyyy"
        let dateOfBirth = dateFormater.date(from: self)
        let calender = Calendar.current
        let dateComponent = calender.dateComponents([.year], from:
            dateOfBirth!, to: Date())
        return "\(dateComponent.year ?? 0)"
    }
    
    func strikeThrough() -> NSAttributedString {
        let attributeString =  NSMutableAttributedString(string: self)
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0,attributeString.length))
        return attributeString
    }
    
    func removeStrikeThrough() -> NSAttributedString {
        let attributeString =  NSMutableAttributedString(string: self)
        return attributeString
    }
    
    static func format(strings: [String],
                    boldFont: UIFont = UIFont.boldSystemFont(ofSize: 14),
                    boldColor: UIColor = UIColor.blue,
                    inString string: String,
                    font: UIFont = UIFont.systemFont(ofSize: 14),
                    color: UIColor = UIColor.black) -> NSAttributedString {
        let attributedString =
            NSMutableAttributedString(string: string,
                                    attributes: [
                                        NSAttributedString.Key.font: font,
                                        NSAttributedString.Key.foregroundColor: color])
        let boldFontAttribute = [NSAttributedString.Key.font: boldFont, NSAttributedString.Key.foregroundColor: boldColor]
        for bold in strings {
            attributedString.addAttributes(boldFontAttribute, range: (string as NSString).range(of: bold))
        }
        return attributedString
    }
    
    static func convertIntoAttributedString(texts : [String],attributs : [[NSAttributedString.Key:AnyObject]]) -> NSAttributedString{
        let attrStr = NSMutableAttributedString()
        for (index,text) in texts.enumerated(){
            attrStr.append(NSAttributedString(string: text, attributes: attributs[index]))
        }
        return attrStr
    }
    
    func containsIgnoringCase(find: String?) -> Bool{
        return self.range(of: find ?? "", options: .caseInsensitive) != nil
    }
    
    static func concate(values : String?...) -> String {
        return values.compactMap({$0}).joined()
    }
    
    func toBool() -> Bool? {
        if self == "0" {
            return false
        }
        else {
            return true
        }
    }
    
    func toInt() -> Int? {
        return Int(self)
    }
    func toFloat() -> Float? {
           return Float(self)
       }
}
