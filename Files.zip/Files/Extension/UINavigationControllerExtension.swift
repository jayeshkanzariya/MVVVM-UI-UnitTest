//
//  UINavigationControllerExtension.swift
//  Muze
//
import UIKit
/// Extension of `UINavigationController` that is used to extend the functions and properties.
extension UINavigationController {
    /// It's used to pop navigation to specified viewcontroller type.
    /// - Parameters:
    ///     - viewController: instance of `UIViewController`.
    ///     - animation: instace of `Bool` that keeps track of animation
    func popTo(viewController: UIViewController.Type, animated: Bool = true) {
        for controller in self.viewControllers as Array {
            if controller.isKind(of: viewController) {
                self.popToViewController(controller, animated: animated)
                break
            }
        }
    }
    /// It's used to add multiple viewcontroller and push through navigation controller.
    /// - Parameters:
    ///     - inViewControllers: that is used to store list of `UIViewController` instances.
    ///     - animation: instace of `Bool` that keeps track of animation
   open func pushViewControllers(_ inViewControllers: [UIViewController], animated: Bool) {
       var stack = self.viewControllers
       stack.append(contentsOf: inViewControllers)
       self.setViewControllers(stack, animated: animated)
   }
}
