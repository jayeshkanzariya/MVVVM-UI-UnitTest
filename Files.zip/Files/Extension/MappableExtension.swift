//
//  MappableExtension.swift
//  FlipScrore
//
//   Created by Pircle on 18/05/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

//import UIKit
//import ObjectMapper
//
//
//extension Mappable  {
//    
//
//}
