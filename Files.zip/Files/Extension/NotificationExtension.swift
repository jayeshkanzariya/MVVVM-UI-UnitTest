//
//  NotificationExtension.swift
//  Muze
//

import Foundation

extension Notification.Name {
    static let sessionUpdated = Notification.Name("sessionUpdated")
    static let profileUpdated = Notification.Name("profileUpdated")
    static let autoLogin = Notification.Name(rawValue: "NotificationAutoLogin")
    static let changeTab = Notification.Name(rawValue: "ChangeTab")
    static let newMessage = Notification.Name(rawValue: "NewMessageArrived")
    static let userEnterForeground = Notification.Name(rawValue: "UserEnterForeGround")
}
