//
//  UIFont+Extension.swift
//  FlipScrore
//
//  Created by Jayesh on 30/04/20.
//  Copyright © 2020 Jayesh kanzariya. All rights reserved.
//

import UIKit

extension UIFont {
    class func quickSandRegular(size : CGFloat) -> UIFont{
        return UIFont(name: "Quicksand-Regular", size: size)!
    }
    
    class func quickSandBold(size : CGFloat) -> UIFont{
        return UIFont(name: "Quicksand-Bold", size: size)!
    }
    
    class func quickSandMedium(size : CGFloat) -> UIFont{
        return UIFont(name: "Quicksand-Medium", size: size)!
    }
    
    class func semiBoldMontserrat(size : CGFloat) -> UIFont{
        return UIFont(name: "Futura Bold", size: size)!
    }
    
    func sizeOfString (string: String, constrainedToWidth width: Double) -> CGSize {
        return NSString(string: string).boundingRect(with: CGSize(width: width, height: Double.greatestFiniteMagnitude),
                                                     options: NSStringDrawingOptions.usesLineFragmentOrigin,
                                                     attributes: [NSAttributedString.Key.font: self],
                                                     context: nil).size
    }
}
