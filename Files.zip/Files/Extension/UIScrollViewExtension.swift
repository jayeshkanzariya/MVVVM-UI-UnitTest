//
//  UIScrollViewExtension.swift
//  Muze
//
//  Created by Pircle on 05/04/20.
//  Copyright © 2020 Pircle. All rights reserved.
//

import UIKit

extension UIScrollView {
    func scrollTo(horizontalPage: Int? = 0, verticalPage: Int? = 0, animated: Bool? = true) {
        var frame: CGRect = self.frame
        frame.origin.x = frame.size.width * CGFloat(horizontalPage ?? 0)
        frame.origin.y = frame.size.width * CGFloat(verticalPage ?? 0)
        self.scrollRectToVisible(frame, animated: animated ?? true)
    }
    
    var currentPage:Int{
        return Int(contentOffset.x / frame.size.width)
    }
}
