//
//  DateExtension.swift
//

import Foundation
/// Extension of `Date` that is used to extend the functions and properties.
extension Date {
    /// It's used to get formatted string from given `Date` instance.
    /// - Parameters:
    ///     - format: instance of `String` that is used for formatter.
    /// -   Returns:
    ///     - returns the formatted string.
    func toString(format: String) -> String {
        let formatter = DateFormatter()
        formatter.timeZone = .current
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
    
    /// Returns the amount of months from another date
    func currentDateMonthAgo() -> Int {
        return Calendar.current.dateComponents([.month], from: self, to: Date()).month ?? 0
    }
       
    /// Returns the amount of days from another date
    func currentDateDayAgo() -> Int {
        return Calendar.current.dateComponents([.day], from: self, to: Date()).day ?? 0
    }
    
    /// Returns the amount of days from another date
    func currentDateYearAgo() -> Int {
        return Calendar.current.dateComponents([.year], from: self, to: Date()).year ?? 0
    }
    
    func daysAgo() -> String {
        let diffDate  = currentDateDayAgo()
        let diffMonth = currentDateMonthAgo()
        let diffYear  = currentDateYearAgo()
        if diffYear > 0 {
            if diffYear <= 1 {
                return "\(diffYear) Year"
            }
            else {
                return "\(diffYear) Years"
            }
        }
        else if diffMonth > 0 {
            if diffMonth <= 1 {
                return "\(diffMonth) Month"
            }
            else {
                return "\(diffMonth) Months"
            }
        }
        else {
            if diffDate <= 1 {
                return "\(diffDate) Day"
            }
            else {
                return "\(diffDate) Days"
            }
        }
    }
}
