//
//  UIApplicationExtension.swift
//  Muze
//
import UIKit
/// Extension of `UIApplication` that is used to extend the functions and properties.
extension UIApplication {
    /// It's used to get top view controller.
    /// - Parameters:
    ///     - base: instance 0f `UIViewController` and that default value is `UIApplication.shared.keyWindow?.rootViewController`
    /// - Returns:
    ///     - returns the instace of `UIViewController`.
    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)
        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)
        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
