//
//  UIView.swift
//
import UIKit
/// extension of `UIView` that is used to extend the functions and properties.
extension UIView : ShadowViewProtocol {
    /// It's used to get instace of Xib view.
    /// - Returns:
    ///     - returns the instance of `UIView` inform of Nib.
    class func fromNib<T: UIView>() -> T {
        return Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)![0] as! T
    }
    /// It's used to get and set the coorner radius in form of `CGFloat`.
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    /// It's used to get and set the border width in form of `CGFloat`.
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    /// It's used to get and set the border color in form of `UIColor`.
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
    /// It's used to get and set the shadow radius in form of `CGFloat`.
    @IBInspectable
    var viewShadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    /// It's used to get and set the shadow opacity in form of `CGFloat`.
    @IBInspectable
    var viewShadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    /// It's used to get and set the shadow offset in form of `CGSize`.
    @IBInspectable
    var viewShadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    /// It's used to get and set the shadow color in form of `UIColor`.
    @IBInspectable
    var viewShadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
    /// It's used to set corenet radius of view.
    /// - Parameters:
    ///     - corners: instace of `UIRectCorner` that is for required corners.
    ///     - radius: instace of `CGFloat` that is for radius point.
    func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }

}

