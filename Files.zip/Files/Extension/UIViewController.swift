//
//  UIViewController.swift
//  Muze
//
import Foundation
import UIKit
import Toast_Swift

/// extension of `UIViewController` that is used to extend the functions and properties.
extension UIViewController {
    /// that returns the instance of `String` that is used as storyboard identifier.
    class var storyboardID: String {
        return "\(self)"
    }
    /// It's used to get instance of any UIViewController type
    /// - Parameters:
    ///     - appStoryboard: Input storyboard containing that UIViewController
    /// - Returns:
    ///     - instance of `UIViewController`
    static func instantiateFrom(appStoryboard: AppStoryboard) -> Self {
        return appStoryboard.viewController(viewControllerClass: self)
    }
    
    func showAlertMessage(title : String? = nil,message : String,complition : (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default) { (action) in
            complition?()
        }
        alertController.addAction(action)
        present(alertController, animated: true, completion: nil)
    }
    
    func showAlertOrActionSheet(type : UIAlertController.Style,title : String?,message : String?,buttons : [String],actionHandler : @escaping ((Int,String) -> ())) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: type)
        for (index,text) in buttons.enumerated(){ //  adding all actions by passin in buttons
            alertController.addAction(UIAlertAction(title: text, style: .default, handler: { (action) in
                actionHandler(index,text) //  return index  and action of title on press
            }))
        }
        if type == .alert {
            alertController.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: { (action) in
                actionHandler(buttons.count + 1,"Cancel")
            }))
        }
        else {
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
                actionHandler(buttons.count + 1,"Cancel")
            }))
        }
        present(alertController, animated: true, completion: nil)
    }
    
    func showErrorToast(message:String)  {
//        Toast(text: message, duration: 1.0).show()
    }
    
    @IBAction func backPressed(_ sender : UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
