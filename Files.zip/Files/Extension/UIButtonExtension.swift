//
//  UIButtonExtension.swift
//  Muze
//

import UIKit

private var AssociatedObjectHandle: UInt8 = 0

extension UIButton {
    
    var passwordTextField : UITextField {
        get {
            return objc_getAssociatedObject(self, &AssociatedObjectHandle) as! UITextField
        }
        set {
            objc_setAssociatedObject(self, &AssociatedObjectHandle, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
}
